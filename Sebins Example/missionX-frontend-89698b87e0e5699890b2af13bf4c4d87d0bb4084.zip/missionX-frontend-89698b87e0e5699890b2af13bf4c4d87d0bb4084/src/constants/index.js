// Add comments on what this is ...etc
export const MAX_AGE = 60 * 60 * 60 * 10;

export const userTypes = {
  STUDENT: 'student',
  TEACHER: 'teacher',
  ADMIN: 'admin',
  PARENT: 'parent',
};
